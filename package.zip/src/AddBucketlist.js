import React, { useState, useEffect } from 'react';
import axios from 'axios';

export function AddBucketlist() {
  const [tags, setTags] = useState([]);
  const [selectedTag, setSelectedTag] = useState('');
  const [minDestBudget, setMinDestBudget] = useState('');
  const [maxDestBudget, setMaxDestBudget] = useState('');
  const [minVlogBudget, setMinVlogBudget] = useState('');
  const [maxVlogBudget, setMaxVlogBudget] = useState('');
  const [destinations, setDestinations] = useState([]);
  const [vlogs, setVlogs] = useState([]);

  useEffect(() => {
    fetchFilters();
  }, []);

  const fetchFilters = async () => {
    try {
      const tagsResponse = await axios.get('http://127.0.0.1:4343/tags');
      console.log(tagsResponse.data)
      setTags(tagsResponse.data.tag);
    } catch (error) {
      console.error('Error fetching filters:', error);
    }
  };

  const handleFilter = async () => {
    try {
      const response = await axios.post('http://127.0.0.1:4343/add-bucketlist/search', {
        selectedTag,
        minDestBudget,
        maxDestBudget,
        minVlogBudget,
        maxVlogBudget
      });
      console.log(selectedTag)
      setDestinations(response.data.destinations);
      setVlogs(response.data.vlogs);
    } catch (error) {
      console.error('Error fetching destinations and vlogs:', error);
    }
  };

  // useEffect(() => {
  //   fetchDestinationsAndVlogs();
  // }, [minDestBudget, maxDestBudget, minVlogBudget, maxVlogBudget]);

  return (
    <div className="container mx-auto mt-8">
      <h1 className="text-3xl font-semibold mb-4">Bucket List</h1>
      <div className="flex mb-4 space-x-4">
        <div className="flex items-center">
          <h2 className="text-xl font-semibold mb-2 mr-2">Filter by Tag:</h2>
          <select
            value={selectedTag}
            onChange={(e) => setSelectedTag(e.target.value)}
            className="border border-gray-300 px-2 py-1 rounded"
          >
            <option value="">Select Tag</option>
            {tags.map(tag => (
              <option key={tag} value={tag}>{tag}</option>
            ))}
          </select>
        </div>
        <div className="flex items-center">
          <input
            type="text"
            placeholder="Min Dest. Budget"
            value={minDestBudget}
            onChange={(e) => setMinDestBudget(e.target.value)}
            className="border border-gray-300 px-2 py-1 rounded mr-2"
          />
          <input
            type="text"
            placeholder="Max Dest. Budget"
            value={maxDestBudget}
            onChange={(e) => setMaxDestBudget(e.target.value)}
            className="border border-gray-300 px-2 py-1 rounded mr-2"
          />
        </div>
        <div className="flex items-center">
          <input
            type="text"
            placeholder="Min Vlog Budget"
            value={minVlogBudget}
            onChange={(e) => setMinVlogBudget(e.target.value)}
            className="border border-gray-300 px-2 py-1 rounded mr-2"
          />
          <input
            type="text"
            placeholder="Max Vlog Budget"
            value={maxVlogBudget}
            onChange={(e) => setMaxVlogBudget(e.target.value)}
            className="border border-gray-300 px-2 py-1 rounded mr-2"
          />
        </div>
        <button
          onClick={handleFilter}
          className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 focus:outline-none"
        >
          Filter
        </button>
      </div>
      <div className="flex space-x-4">
        <div className="w-1/2">
          <h2 className="text-xl font-semibold mb-2">Destinations</h2>
          {destinations.map(destination => (
            <div key={destination.id} className="border p-4 mb-4 rounded-md">
              <h3 className="text-lg font-semibold">{destination.name}</h3>
              <p>{destination.description}</p>
              {/* Add more details as needed */}
            </div>
          ))}
        </div>
        <div className="w-1/2">
          <h2 className="text-xl font-semibold mb-2">Vlogs</h2>
          {vlogs.map(vlog => (
            <div key={vlog.id} className="border p-4 mb-4 rounded-md">
              <h3 className="text-lg font-semibold">{vlog.title}</h3>
              <p>{vlog.description}</p>
              {/* Add more details as needed */}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

 
